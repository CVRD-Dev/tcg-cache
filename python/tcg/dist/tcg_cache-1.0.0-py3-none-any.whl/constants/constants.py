from peewee import SqliteDatabase

DATA_BASE = SqliteDatabase('collection.db')


